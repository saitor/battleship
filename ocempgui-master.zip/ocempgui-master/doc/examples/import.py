import ocempgui          # Main module.
import ocempgui.access   # Accessibility module
import ocempgui.draw     # 2D drawing module
import ocempgui.object   # Basic object module
import ocempgui.events   # Event module
import ocempgui.widgets  # Widget module
